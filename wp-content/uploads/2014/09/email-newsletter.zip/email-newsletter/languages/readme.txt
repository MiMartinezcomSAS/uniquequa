== For Translators ==



Note: 

If you have created your own translation, or have an update of an existing one, please send it to www.gopiplus.com  so that I can bundle it into the next release of this plugin